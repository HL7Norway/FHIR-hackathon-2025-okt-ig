# Home - v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/okt/ImplementationGuide/no.hl7.fhir.okt | *Version*:0.2.0 |
| Draft as of 2025-11-12 | *Computable Name*:OKTonFHIR |

### Introduction

This implementation guide gives suggestions for how the [OKT API](https://utviklerportal.nhn.no/informasjonstjenester/felles-journalloeft/okt-prototype) can be implemented with FHIR resources.

See also [EpisodeOfCare in VKP](https://simplifier.net/guide/velferdsteknologiskknutepunktvkp-r4/episodeofcare?version=current).

### Prototype API models

#### OktEvent

The [`OktEvent`](StructureDefinition-OktEvent.md) model contains a person identifier and an array of [`OktMessage`](StructureDefinition-OktMessage.md) models. The array can be mapped to a Bundle of FHIR resources, moving the person identifier to the Bundle entries.

#### OktMessage

Having discussed several alternatives, including ServiceRequest and CarePlan, the recommendation from the hackathon is to map [`OktMessage`](StructureDefinition-OktMessage.md) to [`EpisodeOfCare`](StructureDefinition-OktEpisodeOfCare.md) resources.

#### OktStatus

`OktStatus` returns the number of services for a person identifier. This can be mapped to a search with the `_summary=count` parameter, which returns a `searchset` Bundle without entries, with the `total` field showing the number of results.

`ResultMessage` can be represented as a Bundle of type `batch-response` or `transaction-response`.

### Mapping to FHIR resources

See [the profile on EpisodeOfCare for OKT](StructureDefinition-OktEpisodeOfCare.md).

#### OktEvent

| | |
| :--- | :--- |
| personIdentifier | EpisodeOfCare.patient1 |
| oktMessages | EpisodeOfCare2 |

Notes:

1 The personIdentifier is added to each resource in the Bundle.
 2 OktEvent is mapped to a Bundle. Each entry in the oktMessages array is an entry in the Bundle.

#### OktMessage

Draft mapping table before the hackathon:

| | | |
| :--- | :--- | :--- |
| endDate1 | string | period.end (dateTime) |
| iplosCode | IplosCodeDefinition | type (CodeableConcept) |
| needsCaption | boolean | type (CodeableConcept) |
| serviceDescription | string | extension (markdown) |
| serviceLevel | string | type (CodeableConcept) |
| startDate | string | period.start (dateTime) |
| stayType | string | type (CodeableConcept) |
| temporaryCessation | boolean | status (code) = on-hold |
| weeklyExtent | string | extension (Ratio2) |

Notes:

1 If a set end date implies that the service has ended, then the profile can restrict with FHIRPath that status = completed implies that occurrencePeriod.end exists.
 2 Denominator (Quantity) fixed to 1 week in the profile.

Changes during the hackathon:

| | | | |
| :--- | :--- | :--- | :--- |
| endDate1 | string | period.end (dateTime) |   |
| iplosCode | IplosCodeDefinition | type (CodeableConcept) |   |
| needsCaption | boolean | type (CodeableConcept) | "Must Support" on serviceDescription; meta.lastUpdated |
| serviceDescription | string | extension (markdown) |   |
| serviceLevel | string | type (CodeableConcept) | managingOrganization (Reference) |
| startDate | string | period.start (dateTime) |   |
| stayType | string | type (CodeableConcept) |   |
| temporaryCessation | boolean | status (code) = on-hold |   |
| weeklyExtent | string | extension (Ratio) | Was Quantity in the profile, changed to Ratio |

#### OktStatus

| | | |
| :--- | :--- | :--- |
| oktStatus | integer | Bundle.total |
| personIdentifier | string | Bundle.link with relation "self" |

### API Interactions

For the FHIR API, `/` is the service base URL.

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
|   | GET /okt-events/{pid} | OktEvent |   | GET /EpisodeOfCare?patient={pid} | Bundle (searchset) of EpisodeOfCare |
| OktEvent | POST /okt-events | {error} | ResultMessage | Bundle (transaction) of EpisodeOfCare | POST / | Bundle (transaction-response) with OperationOutcome |
|   | GET /okt-status/{pid} | OktStatus |   | GET /EpisodeOfCare?patient={pid}&_summary=count | Bundle (searchset) without entries |

### Transformation

The [OktMessage-EpisodeOfCare](StructureMap-OktMessage-EpisodeOfCare.md) StructureMap demonstrates how a structure map can be used to transform the proprietary model to a FHIR resource. The transformation can be executed with the validator CLI, after the IG is built:

`java -jar validator_cli.jar fsh-generated/resources/Binary-OktMessage1.json -output result.xml -transform http://hl7.no/fhir/ig/okt/StructureMap/OktMessage-EpisodeOfCare -ig output`

