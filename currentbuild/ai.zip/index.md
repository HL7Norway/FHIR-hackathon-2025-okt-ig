# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/okt/ImplementationGuide/no.hl7.fhir.okt | *Version*:0.1.0 |
| Draft as of 2025-11-12 | *Computable Name*:OKTonFHIR |

### Introduction

This implementation guide gives suggestions for how the [OKT API](https://utviklerportal.nhn.no/informasjonstjenester/felles-journalloeft/okt-prototype) can be implemented with FHIR resources.

### Prototype API models

#### OktEvent

The [`OktEvent`](StructureDefinition-OktEvent.md) model contains a person identifier and an array of [`OktMessage`](StructureDefinition-OktMessage.md) models. The array can be mapped to a Bundle of FHIR resources, moving the person identifier to the Bundle entries.

#### OktMessage

Mapping [`OktMessage`](StructureDefinition-OktMessage.md) has several FHIR resource candidates:

* ServiceRequest
* EpisodeOfCare
* CarePlan

#### OktStatus

`OktStatus` returns the number of services for a person identifier. This can be mapped to a search with the `_summary=count` parameter, which returns a `searchset` Bundle without entries, with the `total` field showing the number of results.

`ResultMessage` can be represented as aBundle of type `batch-response` or `transaction-response`.

### Summary tables

#### OktEvent

| | | | |
| :--- | :--- | :--- | :--- |
| personIdentifier | ServiceRequest.subject1 | EpisodeOfCare.patient1 | CarePlan.subject |
| oktMessages | ServiceRequest2 | EpisodeOfCare2 | CarePlan.activity |

Notes:

1 The personIdentifier is added to each resource in the Bundle.
 2 OktEvent is mapped to a Bundle. Each entry in the oktMessages array is an entry in the Bundle.

#### OktMessage

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| endDate1 | string | occurrencePeriod.end (dateTime) | period.end (dateTime) | period.end (dateTime) |
| iplosCode | IplosCodeDefinition | code (CodeableConcept) | type (CodeableConcept) | activity.detail.code (CodeableConcept) |
| needsCaption | boolean | orderDetail (CodeableConcept) | type (CodeableConcept) | category (CodeableConcept) |
| serviceDescription | string | note (Annotation) text (markdown) | extension (markdown) | description (string) |
| serviceLevel | string | category (CodeableConcept) | type (CodeableConcept) | category (CodeableConcept) |
| startDate | string | occurrencePeriod.start (dateTime) | period.start (dateTime) | period.start (dateTime) |
| stayType | string | category (CodeableConcept) | type (CodeableConcept) | category (CodeableConcept) |
| temporaryCessation | boolean | status (code) = on-hold | status (code) = on-hold | status (code) = on-hold |
| weeklyExtent | string | quantityRatio (Ratio2) | extension (Ratio) | activity.detail.quantity (SimpleQuantity)3 |

Notes:

1 If a set end date implies that the service has ended, then the profile can restrict with FHIRPath that status = completed implies that occurrencePeriod.end exists.
 2 Denominator (Quantity) fixed to 1 week in the profile.
 3 SimpleQuantity doesn't allow declaring that the amount is a weekly amount.

#### OktStatus

| | | |
| :--- | :--- | :--- |
| oktStatus | integer | Bundle.total |
| personIdentifier | string | Bundle.link with relation "self" |

