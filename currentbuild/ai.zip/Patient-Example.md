# PatientExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientExample**

## Example Patient: PatientExample

Jane Doe Female, DoB: 1980-01-01

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "Example",
  "name" : [
    {
      "family" : "Doe",
      "given" : ["Jane"]
    }
  ],
  "gender" : "female",
  "birthDate" : "1980-01-01"
}

```
