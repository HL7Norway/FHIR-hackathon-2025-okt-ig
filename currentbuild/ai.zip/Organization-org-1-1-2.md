# org-1-1-2 - v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **org-1-1-2**

## Example Organization: org-1-1-2

**name**: Sone Vest

**partOf**: [Organization Hjemmeboende](Organization-org-1-1.md)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "org-1-1-2",
  "name" : "Sone Vest",
  "partOf" : {
    "reference" : "Organization/org-1-1"
  }
}

```
