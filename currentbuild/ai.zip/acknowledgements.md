# Acknowledgements - v0.1.0

* [**Table of Contents**](toc.md)
* **Acknowledgements**

## Acknowledgements

No use of external IP (other than from the FHIR specification)

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (no.hl7.fhir.okt.r4)](package.r4.tgz) and [R4B (no.hl7.fhir.okt.r4b)](package.r4b.tgz) are available.

*There are no Global profiles defined*

### Dependencies



