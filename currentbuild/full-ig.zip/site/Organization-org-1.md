# org-1 - v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **org-1**

## Example Organization: org-1

**name**: Test kommune



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "org-1",
  "name" : "Test kommune"
}

```
